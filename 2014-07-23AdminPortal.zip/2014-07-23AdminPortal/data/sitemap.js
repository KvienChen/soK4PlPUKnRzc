﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h)]);}; 
var b="rootNodes",c="pageName",d="Home",e="type",f="Wireframe",g="url",h="Home.html";
return _creator();
})();
